<?php
// Database connection
include 'db_connect2.php';  // Updated reference

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = mysqli_real_escape_string($conn, $_POST['firstName']);
    $lastName = mysqli_real_escape_string($conn, $_POST['lastName']);
    $uniqueCode = mysqli_real_escape_string($conn, $_POST['uniqueCode']);

    // Check if instructor exists
    $query = "SELECT * FROM instructors WHERE firstName = '$firstName' AND lastName = '$lastName' AND uniqueCode = '$uniqueCode'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Login successful, redirect to instructor dashboard
        header("Location: instructor_dashboard.php");
        exit();
    } else {
        // Incorrect credentials
        echo "<p>Invalid login. Please check your details.</p>";
    }
}
?>
