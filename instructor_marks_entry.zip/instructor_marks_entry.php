<?php
include('db_connect3.php');

// Function to calculate grade based on marks
function calculateGrade($marks) {
    if ($marks >= 80) return 'A';
    elseif ($marks >= 60) return 'B';
    elseif ($marks >= 50) return 'C';
    elseif ($marks >= 40) return 'D';
    else return 'E';
}

// Handle marks submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $adm = $_POST['ADM'];

    foreach ($_POST['marks'] as $unitCode => $marks) {
        $grade = calculateGrade($marks);
        
        // Assign learning resources based on grade
        $resource = match ($grade) {
            'A' => "Advanced Study Materials",
            'B' => "Intermediate Guides",
            'C' => "Standard Books",
            'D' => "Remedial Support",
            'E' => "Extra Coaching"
        };

        // Insert marks into the database
        $query = "INSERT INTO student_grades (adm, unitCode, marks, grade, prescribed_resource) 
                  VALUES ('$adm', '$unitCode', '$marks', '$grade', '$resource')";
        mysqli_query($conn, $query);
    }
    echo "Marks submitted successfully!";
}

// Fetch students
$student_query = "SELECT adm, firstName, lastName FROM students";
$student_result = mysqli_query($conn, $student_query);

// Fetch available courses
$course_query = "SELECT unitCode, unitName FROM courses";
$course_result = mysqli_query($conn, $course_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Enter Marks</title>
    <!-- Link to the CSS file -->
    <link rel="stylesheet" href="instructor_marks_entry.css"> <!-- Correct link to the CSS -->
</head>
<body>
    <h2>Enter Marks for Students</h2>

    <form method="post">
        <label>Select Student:</label>
        <select name="ADM" required>
            <?php while ($row = mysqli_fetch_assoc($student_result)): ?>
                <option value="<?= $row['adm'] ?>">
                    <?= $row['firstName'] . " " . $row['lastName'] ?>
                </option>
            <?php endwhile; ?>
        </select>

        <h3>Enter Marks</h3>
        <?php while ($row = mysqli_fetch_assoc($course_result)): ?>
            <label><?= $row['unitName'] ?>:</label>
            <input type="number" name="marks[<?= $row['unitCode'] ?>]" min="0" max="100" required><br>
        <?php endwhile; ?>

        <button type="submit">Submit Marks</button>
    </form>
</body>
</html>