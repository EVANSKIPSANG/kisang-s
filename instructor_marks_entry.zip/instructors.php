<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_management_system";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert data into the 'instructors' table
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addInstructor'])) {
    $firstName = htmlspecialchars($_POST['firstName']);
    $lastName = htmlspecialchars($_POST['lastName']);
    $uniqueCode = htmlspecialchars($_POST['uniqueCode']);

    $sql = "INSERT INTO instructors (firstName, lastName, uniqueCode) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $firstName, $lastName, $uniqueCode);

    if ($stmt->execute()) {
        echo "<p class='success'>Instructor added successfully.</p>";
    } else {
        echo "<p class='error'>Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

// Delete instructor
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);

    // Fetch instructor details before deletion
    $fetch_sql = "SELECT firstName, lastName FROM instructors WHERE id = ?";
    $fetch_stmt = $conn->prepare($fetch_sql);
    $fetch_stmt->bind_param("i", $delete_id);
    $fetch_stmt->execute();
    $fetch_stmt->bind_result($firstName, $lastName);
    $fetch_stmt->fetch();
    $fetch_stmt->close();

    if ($firstName && $lastName) {
        // Proceed with deletion
        $delete_sql = "DELETE FROM instructors WHERE id = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("i", $delete_id);

        if ($delete_stmt->execute()) {
            echo "<p class='success'>Instructor $firstName $lastName deleted successfully.</p>";
        } else {
            echo "<p class='error'>Error deleting instructor.</p>";
        }

        $delete_stmt->close();
    }
}

// Retrieve and display instructors
$sql = "SELECT id, firstName, lastName, uniqueCode FROM instructors";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructor Management</title>
    <link rel="stylesheet" type="text/css" href="instructors.css">
    <script>
        function toggleList() {
            var listSection = document.getElementById("instructorList");
            listSection.style.display = (listSection.style.display === "none") ? "block" : "none";
        }

        function confirmDelete(id, firstName, lastName) {
            if (confirm("Are you sure you want to delete " + firstName + " " + lastName + "?")) {
                window.location.href = "instructors.php?delete_id=" + id;
            }
        }
    </script>
</head>
<body>
    <!-- Top Buttons for Navigation -->
    <div class="top-buttons">
        <a href="add_course.php">Add Courses</a>
        <a href="admin_label_courses.php">Popular Courses</a>
    </div>

    <h2>Add Instructor</h2>
    <form method="post" action="">
        <input type="text" name="firstName" placeholder="First Name" required><br>
        <input type="text" name="lastName" placeholder="Last Name" required><br>
        <input type="text" name="uniqueCode" placeholder="Unique Code" required><br>
        <input type="submit" name="addInstructor" value="Add Instructor">
    </form>

    <button onclick="toggleList()">Instructors List</button>

    <div id="instructorList" style="display: none;">
        <h2>Instructors List</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Unique Code</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['firstName']); ?></td>
                <td><?php echo htmlspecialchars($row['lastName']); ?></td>
                <td><?php echo htmlspecialchars($row['uniqueCode']); ?></td>
                <td>
                    <button class="delete-btn" onclick="confirmDelete(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars($row['firstName']); ?>', '<?php echo htmlspecialchars($row['lastName']); ?>')">Delete</button>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>

<?php
$conn->close();
?>
