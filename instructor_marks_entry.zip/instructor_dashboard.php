<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome to Dashboard</title>
    <style>
        /* Apply general styling to the page */
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background: url('uploads/pexelIinstructor.jpg') no-repeat center center fixed; 
            background-size: cover; 
            background-position: center;
            padding: 20px;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        /* Moving Text Animation */
        .moving-text {
            font-size: 30px;
            font-weight: bold;
            color:rgb(10, 10, 10);
            position: relative;
            display: inline-block;
            white-space: nowrap;
            animation: moveText 5s linear infinite alternate;
        }

        /* Animation for moving text */
        @keyframes moveText {
            0% { transform: translateX(-20%); }  
            100% { transform: translateX(20%); }  
        }

        /* Button Container */
        .button-container {
            position: absolute;
            bottom: 50%; /* 3/4 from the bottom */
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 15px; /* Space between buttons */
            flex-wrap: wrap;
            justify-content: center;
            width: 80%;
        }

        /* Button Styling */
        button {
            padding: 12px 24px;
            font-size: 16px;
            background-color:rgb(13, 5, 49);
            color: white;
            border: none;
            cursor: pointer;
            transition: background 0.3s ease-in-out;
            border-radius: 5px;
            outline: none;
            position: relative;
            z-index: 0;
            overflow: hidden;
        }

        /* Glow Effect */
        button::before {
            content: "";
            position: absolute;
            top: -2px;
            left: -2px;
            width: calc(100% + 4px);
            height: calc(100% + 4px);
            background: linear-gradient(
                45deg,
                #FF0000, #FF7300, #FFFB00, #48FF00,
                #00FFD5, #002BFF, #FF00C8, #FF0000
            );
            background-size: 400%;
            z-index: -1;
            border-radius: 5px;
            filter: blur(8px);
            opacity: 0;
            transition: opacity 0.3s ease-in-out;
            animation: glowing 20s linear infinite;
        }

        /* Hover Effect */
        button:hover::before {
            opacity: 1;
        }

        /* Active button effect */
        button:active:after {
            background: transparent;
        }

        button:active {
            color: #000;
            font-weight: bold;
        }

        /* Glowing Animation */
        @keyframes glowing {
            0% { background-position: 0 0; }
            50% { background-position: 400% 0; }
            100% { background-position: 0 0; }
        }

        /* Add responsiveness */
        @media screen and (max-width: 768px) {
            .moving-text {
                font-size: 20px;
            }

            button {
                font-size: 14px;
                padding: 10px 20px;
            }

            .button-container {
                bottom: 20%; /* Adjust for smaller screens */
                width: 90%;
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <h1 class="moving-text">Welcome back to your Dashboard</h1>

    <!-- Button Container -->
    <div class="button-container">
        <a href="instructor_marks_entry.php">
            <button>Enter Student Marks</button>
        </a>
        <a href="upload_resource.php">
            <button>Upload Resource</button>
        </a>
        <a href="instructor_upload.php">
            <button>Upload Exams/Assignments</button>
        </a>
        <a href="view_solutions.php">
            <button>Solutions to Assignments</button>
        </a>
        <a href="bio_insert.php">
            <button>Add Your Bio</button>
        </a>
        <a href="lecturer_update_email.php">
            <button>Mail Broadcast</button>
        </a>
    </div>
</body>
</html>
