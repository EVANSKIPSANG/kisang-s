<?php
session_start();
include("db_connect.php"); // Include database connection

// Redirect non-instructor users to the homepage
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'instructor') {
    header("Location: user_homepage.php");
    exit();
}

// Handle form submissions (Resource upload and Marks entry)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['upload_resource'])) {
        // Handle resource upload
        $grade = $_POST['grade'];
        $resourceTitle = $_POST['resource_title'];
        $file = $_FILES['resource_file'];

        // Validate and upload file
        $allowedExtensions = ['pdf', 'doc', 'docx'];
        $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);

        if (in_array($fileExtension, $allowedExtensions)) {
            $uploadDir = 'uploads/resources/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $filePath = $uploadDir . basename($file['name']);
            if (move_uploaded_file($file['tmp_name'], $filePath)) {
                $query = "INSERT INTO resources (grade, title, file_path) VALUES ('$grade', '$resourceTitle', '$filePath')";
                mysqli_query($conn, $query);
                echo "Resource uploaded successfully!";
            } else {
                echo "Error uploading file.";
            }
        } else {
            echo "Invalid file format. Only PDF, DOC, and DOCX are allowed.";
        }
    }

    if (isset($_POST['submit_marks'])) {
        // Handle student marks input
        $studentId = $_POST['student_id'];
        $courseName = $_POST['course_name'];
        $grade = $_POST['grade'];

        $query = "INSERT INTO student_grades (student_id, course_name, grade) VALUES ('$studentId', '$courseName', '$grade')";
        if (mysqli_query($conn, $query)) {
            echo "Marks submitted successfully!";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructor Operations</title>
    <link rel="stylesheet" href="instructor_operations.css">
</head>
<body>
    <div class="content">
        <h1>Instructor Operations</h1>
        <form method="POST" enctype="multipart/form-data">
            <h2>Upload Resource</h2>
            <label for="grade">Grade:</label>
            <select name="grade" id="grade" required>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
            </select>
            <label for="resource_title">Resource Title:</label>
            <input type="text" name="resource_title" id="resource_title" required>
            <label for="resource_file">Upload File:</label>
            <input type="file" name="resource_file" id="resource_file" required>
            <button type="submit" name="upload_resource">Upload</button>
        </form>

        <form method="POST">
            <h2>Input Student Marks</h2>
            <label for="student_id">Student ID:</label>
            <input type="text" name="student_id" id="student_id" required>
            <label for="course_name">Course Name:</label>
            <input type="text" name="course_name" id="course_name" required>
            <label for="grade">Grade:</label>
            <select name="grade" id="grade" required>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
            </select>
            <button type="submit" name="submit_marks">Submit Marks</button>
        </form>

        <a href="academics.php" class="back-button">Back to Academics</a>
    </div>
</body>
</html>
