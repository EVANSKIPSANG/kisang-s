<?php
include 'db_connect8.php';

// Fetch all groups
$groupsQuery = "SELECT * FROM groups8";
$groupsResult = $conn->query($groupsQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Instructor Panel</title>
    <link rel="stylesheet" href="style8.css">
    <script src="script8.js" defer></script>
</head>
<body>
    <h1>Instructor Dashboard</h1>

    <form method="post" action="instructor8.php">
        <input type="text" name="instructor_id" placeholder="Instructor ID" required>
        <input type="text" name="group_name" placeholder="Group Name (A, B, C...)" required>
        <input type="text" name="title" placeholder="Discussion Title" required>
        <input type="number" name="member_limit" placeholder="Member Limit" required>
        <button type="submit" name="create_group">Create Group</button>
    </form>

    <h2>Existing Groups</h2>
    <ul id="groupList">
        <?php while ($group = $groupsResult->fetch_assoc()) { ?>
            <li class="group-item" data-group-id="<?= $group['id']; ?>">
                <?= $group['group_name'] . " - " . $group['title']; ?>
                <span class="status <?= $group['status'] === 'pending' ? 'blink' : ''; ?>">●</span>
            </li>
        <?php } ?>
    </ul>

    <div id="discussionArea"></div>
</body>
</html>

<?php
if (isset($_POST['create_group'])) {
    $instructor_id = $_POST['instructor_id'];
    $group_name = $_POST['group_name'];
    $title = $_POST['title'];
    $member_limit = $_POST['member_limit'];

    $query = "INSERT INTO groups8 (instructor_id, group_name, title, member_limit, status) 
              VALUES ('$instructor_id', '$group_name', '$title', '$member_limit', 'active')";
    
    if ($conn->query($query)) {
        header("Location: instructor8.php");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
