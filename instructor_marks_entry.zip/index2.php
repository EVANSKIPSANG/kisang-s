<!DOCTYPE html>
<html lang="en">
<head>
    <title>Learning Hub</title>
    <link rel="stylesheet" href="home_styles.css">
    <style>
        /* Scrollable review section */
        #reviews-container {
            overflow-x: auto;
            white-space: nowrap;
            display: flex;
            padding: 20px;
            gap: 20px;
            scroll-behavior: smooth;
            max-width: 100%;
        }

        .review {
            width: 250px;
            min-width: 250px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            background: #fff;
            text-align: center;
            display: inline-block;
        }

        .review h3 {
            margin-bottom: 5px;
            font-size: 18px;
            color: #333;
        }

        .review p {
            font-size: 14px;
            color: #666;
        }

        .review .stars {
            color: #FFD700; /* Gold color for stars */
            font-size: 18px;
            margin-top: 10px;
        }

        .review small {
            display: block;
            margin-top: 10px;
            font-weight: bold;
            color: #007BFF;
        }
    </style>
    <script>
        function toggleResults() {
            var resultsDiv = document.getElementById("search-results");
            if (resultsDiv.style.display === "none") {
                resultsDiv.style.display = "block";
            } else {
                resultsDiv.style.display = "none";
            }
        }
    </script>
</head>
<body>

    <!-- Search Bar -->
    <section id="search-bar">
        <form method="POST">
            <input type="text" name="search_query" placeholder="Search for learning materials..." required>
            <button type="submit">Search</button>
            <button type="button" onclick="toggleResults()">Collapse search</button>
        </form>
    </section>

    <!-- Search Results -->
    <section id="search-results">
        <?php
        include 'db_conne88ct.php';

        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search_query'])) {
            $search_query = mysqli_real_escape_string($conn, $_POST['search_query']);

            $query = "SELECT c.course_id, c.course_name, c.course_description, i.image_url 
                      FROM home_courses c
                      LEFT JOIN home_course_images i ON c.course_id = i.course_id
                      WHERE c.course_name LIKE '%$search_query%' OR c.course_description LIKE '%$search_query%'";

            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<div class='course-card'>
                            <img src='" . htmlspecialchars($row['image_url']) . "' alt='Course Image'>
                            <h3>" . htmlspecialchars($row['course_name']) . "</h3>
                            <p>" . htmlspecialchars($row['course_description']) . "</p>
                            <button>Enroll Now</button>
                          </div>";
                }
                echo "<script>document.getElementById('search-results').style.display = 'block';</script>"; // Auto-show results
            } else {
                echo "<p>No courses available at the moment.</p>";
                echo "<script>document.getElementById('search-results').style.display = 'block';</script>";
            }
        }
        ?>
    </section>

    <!-- Popular Courses -->
    <section id="popular-courses">
        <h2>Popular Courses</h2>
        <?php include 'fetch_popular_courses.php'; ?>
    </section>

    <!-- Student Reviews -->
    <section id="reviews">
        <h2>Student Reviews</h2>
        <div id="reviews-container">
            <?php
            include 'db_conne88ct.php';
            $review_query = "SELECT * FROM home_reviews ORDER BY review_date DESC LIMIT 5";
            $reviews = mysqli_query($conn, $review_query);
            while ($review = mysqli_fetch_assoc($reviews)) {
                echo "<div class='review'>";
                echo "<h3>" . htmlspecialchars($review['student_name']) . "</h3>";
                echo "<p>" . htmlspecialchars($review['review_text']) . "</p>";
                
                // Convert rating number to stars
                $rating = intval($review['rating']);
                echo "<div class='stars'>";
                for ($i = 1; $i <= 5; $i++) {
                    if ($i <= $rating) {
                        echo "★"; // Filled star
                    } else {
                        echo "☆"; // Empty star
                    }
                }
                echo "</div>";

                echo "<small>Rating: " . $review['rating'] . "/5</small>";
                echo "</div>";
            }
            ?>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Learning Hub</p>
    </footer>

</body>
</html>
