<?php
include 'db_connect_assignment.php'; // Connect to database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $unitCode = $_POST['unitCode'];
    $unitName = $_POST['unitName'];
    $sessionEnd = $_POST['sessionEnd'];
    $uploadTime = date("Y-m-d H:i:s");

    // File upload handling
    $targetDir = "uploads/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    $fileName = basename($_FILES["resource"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    $allowedTypes = ['pdf', 'doc', 'docx'];
    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES["resource"]["tmp_name"], $targetFilePath)) {
            // Insert into database
            $query = "INSERT INTO assignments (unitCode, unitName, resource, uploadTime, sessionEnd) 
                      VALUES ('$unitCode', '$unitName', '$fileName', '$uploadTime', '$sessionEnd')";
            if (mysqli_query($conn, $query)) {
                echo "Assignment uploaded successfully.";
            } else {
                echo "Database error: " . mysqli_error($conn);
            }
        } else {
            echo "File upload error.";
        }
    } else {
        echo "Invalid file type.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Instructor Dashboard</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Assignment</title>
    <!-- Link to the CSS file -->
    <link rel="stylesheet" href="instructor_upload.css">
</head>
<body>

<form action="" method="POST" enctype="multipart/form-data">
    <label>Unit Code:</label>
    <input type="text" name="unitCode" required>
    
    <label>Unit Name:</label>
    <input type="text" name="unitName" required>
    
    <label>Upload Assignment (PDF, Word):</label>
    <input type="file" name="resource" required>
    
    <label>Session End:</label>
    <input type="datetime-local" name="sessionEnd" required>
    
    <button type="submit">Upload Assignment</button>
</form>

</body>
</html>
