const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const cors = require("cors");

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(cors());
app.use(express.static("public"));

io.on("connection", (socket) => {
    console.log("New user connected:", socket.id);

    // Handle incoming messages
    socket.on("chatMessage", (data) => {
        io.emit("chatMessage", data); // Broadcast message with username
    });

    socket.on("disconnect", () => {
        console.log("User disconnected:", socket.id);
    });
});

const PORT = 3007;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
