<?php
include 'db_connect8.php';

// Fetch available groups
$groupsQuery = "SELECT * FROM groups8";
$groupsResult = $conn->query($groupsQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Panel</title>
    <link rel="stylesheet" href="style8.css">
    <script src="script8.js" defer></script>
</head>
<body>
    <h1>Student Dashboard</h1>

    <h2>Join a Group</h2>
    <form method="post" action="student8.php">
        <select name="group_id" required>
            <?php while ($group = $groupsResult->fetch_assoc()) { ?>
                <option value="<?= $group['id']; ?>"><?= $group['group_name'] . " - " . $group['title']; ?></option>
            <?php } ?>
        </select>
        <input type="text" name="admission_number" placeholder="Admission Number" required>
        <button type="submit" name="join_group">Join</button>
    </form>

    <h2>Group Discussion</h2>
    <textarea id="discussionBox" placeholder="Start typing..."></textarea>
    <button id="thumbUp">👍</button>
    <button id="thumbDown">👎</button>
    <button id="submitWork">Submit</button>
</body>
</html>

<?php
if (isset($_POST['join_group'])) {
    $group_id = $_POST['group_id'];
    $admission_number = $_POST['admission_number'];

    $query = "INSERT INTO student_groups8 (group_id, admission_number) VALUES ('$group_id', '$admission_number')";
    if ($conn->query($query)) {
        header("Location: student8.php");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
