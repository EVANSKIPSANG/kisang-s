<?php
include("db_connect.php"); // Include database connection

// Fetch all available resources
$query = "SELECT * FROM resources";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Resources</title>
    <link rel="stylesheet" href="student_resources.css">
</head>
<body>
    <div class="content">
        <h1>Available Resources</h1>
        <ul>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <li>
                    <strong><?php echo $row['title']; ?></strong> 
                    (<a href="<?php echo $row['file_path']; ?>" download>Download</a>)
                </li>
            <?php endwhile; ?>
        </ul>
        <a href="academics.php" class="back-button">Back to Academics</a>
    </div>
</body>
</html>

