<?php
include 'db_connect8.php';

$group_id = $_POST['group_id'];
$query = "UPDATE groups8 SET status='pending' WHERE id='$group_id'";
$conn->query($query);
?>
