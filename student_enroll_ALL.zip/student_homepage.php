<?php
include 'db_connect_assignment.php';

// Fetch available assignments
$current_time = date("Y-m-d H:i:s");
$query = "SELECT * FROM assignments WHERE sessionEnd > '$current_time' ORDER BY uploadTime DESC";
$result = mysqli_query($conn, $query);

// Check for new assignments
$newAssignment = mysqli_num_rows($result) > 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="notification_style.css">
    <link rel="stylesheet" href="student_homepage.css">
</head>
<a href="user_homepage.php" style="position: absolute; top: 20px; right: 20px; padding: 10px 15px; background-color: #28a745; color: white; font-size: 16px; font-weight: bold; border-radius: 5px; text-decoration: none; cursor: pointer;">
    Back to Home
</a>

<body>
    <?php if ($newAssignment): ?>
        <button class="notify">New Assignment Available!</button>
    <?php endif; ?>

    <h2>Available Assignments</h2>
    <table border="1">
        <tr>
            <th>Unit Code</th>
            <th>Unit Name</th>
            <th>Resource</th>
            <th>Upload Time</th>
            <th>Session End</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?php echo $row['unitCode']; ?></td>
                <td><?php echo $row['unitName']; ?></td>
                <td><a href="uploads/<?php echo $row['resource']; ?>" download>Download</a></td>
                <td><?php echo $row['uploadTime']; ?></td>
                <td><?php echo $row['sessionEnd']; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
