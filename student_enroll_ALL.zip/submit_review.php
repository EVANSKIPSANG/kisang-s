<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_name = mysqli_real_escape_string($conn, $_POST['student_name']);
    $course_id = mysqli_real_escape_string($conn, $_POST['course_id']);
    $review_text = mysqli_real_escape_string($conn, $_POST['review_text']);
    $rating = mysqli_real_escape_string($conn, $_POST['rating']);

    $query = "INSERT INTO home_reviews (student_name, course_id, review_text, rating, review_date)
              VALUES ('$student_name', '$course_id', '$review_text', '$rating', NOW())";

    if (mysqli_query($conn, $query)) {
        echo "Review submitted successfully.";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
