<?php
include 'db_connect_assignment.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admission = $_POST['admission'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    
    $targetDir = "solutions/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    $fileName = basename($_FILES["solution"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    $allowedTypes = ['pdf', 'doc', 'docx'];
    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES["solution"]["tmp_name"], $targetFilePath)) {
            // Insert into database
            $query = "INSERT INTO solutions (admission, fname, lname, solution) 
                      VALUES ('$admission', '$fname', '$lname', '$fileName')";
            if (mysqli_query($conn, $query)) {
                echo "Solution submitted successfully.";
            } else {
                echo "Database error: " . mysqli_error($conn);
            }
        } else {
            echo "File upload error.";
        }
    } else {
        echo "Invalid file type.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Solution</title>
    <link rel="stylesheet" href="submit_solution.css">
    <a href="user_homepage.php" style="position: absolute; top: 20px; right: 20px; padding: 10px 15px; background-color:rgb(40, 66, 212); color: white; font-size: 16px; font-weight: bold; border-radius: 5px; text-decoration: none; cursor: pointer;">
    Back to Home
</a>

</head>
<body style="background: url('images/homepage5.jpg') no-repeat center center fixed; background-size: cover;">

<form action="" method="POST" enctype="multipart/form-data">
    <label>Admission Number:</label>
    <input type="text" name="admission" required>
    <label>First Name:</label>
    <input type="text" name="fname" required>
    <label>Last Name:</label>
    <input type="text" name="lname" required>
    <label>Upload Solution (PDF, Word):</label>
    <input type="file" name="solution" required>
    <button type="submit">Submit Solution</button>
</form>

</body>
</html>

