<?php
// Include database connection
include('db_connect3.php');

$error_message = "";
$student_data = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ADM = trim($_POST['ADM']); // Get ADM from input

    // Validate ADM input
    if (empty($ADM)) {
        $error_message = "Please enter your ADM number.";
    } else {
        // Fetch student grades & resources based on ADM
        $query = "SELECT * FROM student_grades WHERE ADM = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $ADM);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $student_data[] = $row;
            }
        } else {
            $error_message = "No records found for ADM: " . htmlspecialchars($ADM);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="student_dashboard.css">
    <a href="user_homepage.php" style="position: absolute; top: 20px; right: 20px; padding: 10px 15px; background-color: #28a745; color: white; font-size: 16px; font-weight: bold; border-radius: 5px; text-decoration: none; cursor: pointer;">
    Back to Home
</a>

</head>
<body>

    <div class="container">
        <h2>Student Dashboard</h2>

        <form method="POST">
            <label for="ADM">Enter Your ADM Number:</label>
            <input type="text" name="ADM" required>
            <button type="submit">View Results</button>
        </form>

        <?php if ($error_message): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <?php if (!empty($student_data)): ?>
            <h3>Your Academic Records</h3>
            <table>
                <tr>
                    <th>ADM</th>
                    <th>Unit Code</th>
                    <th>Marks</th>
                    <th>Grade</th>
                    <th>Prescribed Resource</th>
                </tr>
                <?php foreach ($student_data as $student): ?>
                <tr>
                    <td><?php echo htmlspecialchars($student['ADM']); ?></td>
                    <td><?php echo htmlspecialchars($student['unitCode']); ?></td>
                    <td><?php echo htmlspecialchars($student['marks']); ?></td>
                    <td><?php echo htmlspecialchars($student['grade']); ?></td>
                    <td><?php echo htmlspecialchars($student['prescribed_resource']); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

</body>
</html>
