<?php
include 'db_conne88ct.php'; // Database connection

// Handle review submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_id = $_POST['course_id'];
    $student_name = $_POST['student_name'];
    $review_text = $_POST['review_text'];
    $rating = $_POST['rating'];

    // Insert the review into the database
    $sql = "INSERT INTO home_reviews (course_id, student_name, review_text, rating) 
            VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issi", $course_id, $student_name, $review_text, $rating);

    if ($stmt->execute()) {
        echo "<script>alert('Review submitted successfully!');</script>";
    } else {
        echo "<script>alert('Error submitting review.');</script>";
    }
}

// Fetch all courses
$courses = $conn->query("SELECT course_id, course_name FROM home_courses");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Course Review</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Review Form Container */
        .review-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 15px;
        }

        /* Form Inputs */
        label {
            display: block;
            font-weight: bold;
            margin: 10px 0 5px;
            text-align: left;
        }

        select, input, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 10px;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
            height: 80px;
        }

        /* Submit Button */
        button {
            background: #27ae60;
            border: none;
            color: white;
            padding: 12px;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            transition: background 0.3s ease;
        }

        button:hover {
            background: #1e8449;
        }
    </style>
</head>
<body>

    <div class="review-container">
        <h2>Submit Course Review</h2>
        <form method="POST">
            <label for="course">Select Course:</label>
            <select name="course_id" required>
                <?php while ($course = $courses->fetch_assoc()): ?>
                    <option value="<?= $course['course_id']; ?>"><?= $course['course_name']; ?></option>
                <?php endwhile; ?>
            </select>

            <label for="student_name">Your Name:</label>
            <input type="text" name="student_name" required>

            <label for="review_text">Your Review:</label>
            <textarea name="review_text" required></textarea>

            <label for="rating">Rating (1-5):</label>
            <input type="number" name="rating" min="1" max="5" required>

            <button type="submit">Submit Review</button>
        </form>
    </div>

</body>
</html>
