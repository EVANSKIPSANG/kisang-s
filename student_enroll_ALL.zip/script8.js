document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("submitWork").addEventListener("click", function() {
        fetch("submit_status8.php", { method: "POST" })
            .then(response => response.text())
            .then(data => alert("Work Submitted!"));
    });
});
