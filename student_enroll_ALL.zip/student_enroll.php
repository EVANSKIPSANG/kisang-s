<?php
include('db_connect3.php');

$error_message = "";
$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ADM = $_POST['ADM'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];

    // Insert student into the database if not exists
    $query = "INSERT IGNORE INTO students (ADM, firstName, lastName) VALUES ('$ADM', '$firstName', '$lastName')";
    mysqli_query($conn, $query);

    if (!empty($_POST['courses'])) {
        foreach ($_POST['courses'] as $unitCode) {
            $query = "INSERT INTO student_enrollments (ADM, unitCode) VALUES ('$ADM', '$unitCode')";
            mysqli_query($conn, $query);
        }
        $success_message = "Enrollment successful!";
    } else {
        $error_message = "Please select at least one course.";
    }
}

// Fetch available courses
$course_result = mysqli_query($conn, "SELECT * FROM courses");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Courses Results</title>
</head>
<body>
    <h2>Enroll in Courses</h2>
    <?php if ($error_message) echo "<p style='color:red;'>$error_message</p>"; ?>
    <?php if ($success_message) echo "<p style='color:green;'>$success_message</p>"; ?>
    
    <form method="post">
        <label>ADM:</label>
        <input type="text" name="ADM" required>
        <label>First Name:</label>
        <input type="text" name="firstName" required>
        <label>Last Name:</label>
        <input type="text" name="lastName" required>

        <h3>Select Courses:</h3>
        <?php while ($row = mysqli_fetch_assoc($course_result)): ?>
            <input type="checkbox" name="courses[]" value="<?= $row['unitCode'] ?>"> <?= $row['unitName'] ?><br>
        <?php endwhile; ?>

        <button type="submit">Enroll</button>
    </form>
</body>
</html>
<head>
    <title>Courses Enrollment</title>
    <link rel="stylesheet" href="student_enroll.css">
    <a href="user_homepage.php" style="position: absolute; top: 20px; right: 20px; padding: 10px 15px; background-color: #28a745; color: white; font-size: 16px; font-weight: bold; border-radius: 5px; text-decoration: none; cursor: pointer;">
    Back to Home
</a>

</head>
