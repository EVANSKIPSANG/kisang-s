<?php
include 'db_config7.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $message = $_POST['message'];

    // Insert message into database
    $sql = "INSERT INTO messages (message) VALUES ('$message')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Message saved";
    } else {
        echo "Error: " . $conn->error;
    }
    
    $conn->close();
}
?>
