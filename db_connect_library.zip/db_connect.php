<?php
// Database connection file
$host = "localhost";
$user = "root";
$pass = ""; // Default password for localhost, change as needed
$db = "user_management_system";

// Establishing connection to MySQL
$conn = new mysqli($host, $user, $pass, $db);

// Checking for connection errors
if ($conn->connect_error) {
    die("Failed to connect to the database: " . $conn->connect_error);
}
?>
