<?php
include "db_connect_library.php";

// Process delete request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $category = $_POST["category"];

    // Delete file from storage
    $query = "SELECT Upload FROM $category WHERE id = '$id'";
    $result = mysqli_query($conn, $query);
    $file = mysqli_fetch_assoc($result);

    if (file_exists($file["Upload"])) {
        unlink($file["Upload"]);
    }

    // Delete from database
    mysqli_query($conn, "DELETE FROM $category WHERE id = '$id'");
    echo "Resource deleted successfully.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Resource</title>
    <link rel="stylesheet" href="delete_resource.css">
</head>
<body>
    <h2>Delete Resource</h2>
    <form method="POST">
        <label>Enter unit ID:</label>
        <input type="text" name="id" required>

        <label>Select Category:</label>
        <select name="category" required>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
            <option value="E">E</option>
        </select>

        <button type="submit">Delete Resource:</button>
    </form>
</body>
</html>
