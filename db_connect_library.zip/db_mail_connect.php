<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "user_management_system"; // Change to your actual database

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
