<?php
// Database connection details
$host = "localhost";
$user = "root";
$password = "";
$dbname = "resource_management";

// Establish connection
$conn = mysqli_connect($host, $user, $password, $dbname);

// Check connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
