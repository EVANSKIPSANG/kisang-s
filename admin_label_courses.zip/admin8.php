<?php
// admin8.php - Admin page to manage groups and students
include 'db_connect8.php';

if (isset($_POST['add_group'])) {
    $group_name = $_POST['group_name'];
    $title = $_POST['title'];

    // Insert new group into the groups table
    $query = "INSERT INTO groups8 (group_name, title) VALUES ('$group_name', '$title')";
    if ($conn->query($query)) {
        echo "Group added successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Admin Dashboard</h1>

    <h2>Add New Group</h2>
    <form method="post" action="admin8.php">
        <input type="text" name="group_name" placeholder="Group Name" required>
        <input type="text" name="title" placeholder="Group Title" required>
        <button type="submit" name="add_group">Add Group</button>
    </form>
</body>
</html>
