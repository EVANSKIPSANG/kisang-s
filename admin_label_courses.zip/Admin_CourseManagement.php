<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "homepage";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle course addition
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_course"])) {
    $course_id = $_POST["course_id"];
    $course_name = $_POST["course_name"];
    $course_description = $_POST["course_description"];
    $is_popular = isset($_POST["is_popular"]) ? 1 : 0; // 1 if checked, 0 if not

    $sql = "INSERT INTO home_courses (course_id, course_name, course_description, is_popular) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issi", $course_id, $course_name, $course_description, $is_popular);

    if ($stmt->execute()) {
        echo "<script>alert('Course added successfully!');</script>";
    } else {
        echo "<script>alert('Error adding course.');</script>";
    }
}

// Handle course deletion (AJAX request)
if (isset($_POST["delete_id"])) {
    $delete_id = $_POST["delete_id"];
    $sql = "DELETE FROM home_courses WHERE course_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    exit;
}

// Handle toggle "popular" status (AJAX)
if (isset($_POST["toggle_id"])) {
    $toggle_id = $_POST["toggle_id"];
    $new_status = $_POST["new_status"];
    
    $sql = "UPDATE home_courses SET is_popular = ? WHERE course_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $new_status, $toggle_id);
    $stmt->execute();
    exit;
}

// Fetch all courses
$courses = $conn->query("SELECT * FROM home_courses");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Courses</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-top: 20px;
        }

        /* Form Styling */
        .form-container {
            background: white;
            padding: 20px;
            margin: 20px auto;
            width: 400px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: left;
        }

        label {
            display: block;
            font-weight: bold;
            margin-top: 10px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 5px;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }

        .checkbox-container input {
            width: auto;
            margin-right: 10px;
        }

        button {
            background: #27ae60;
            border: none;
            color: white;
            padding: 12px;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 10px;
        }

        button:hover {
            background: #1e8449;
        }

        /* Table Styling */
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #021222;
            color: white;
        }

        .popular-label {
            font-weight: bold;
        }

        .delete-btn {
            background: red;
            color: white;
            padding: 6px 10px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            text-decoration: none;
        }

        .delete-btn:hover {
            background: darkred;
        }
    </style>

    <!-- jQuery for AJAX (to delete and update courses dynamically) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

    <h2>Admin - Manage Courses</h2>

    <!-- Course Addition Form -->
    <div class="form-container">
        <form method="POST">
            <label for="course_id">Course ID:</label>
            <input type="number" name="course_id" required>

            <label for="course_name">Course Name:</label>
            <input type="text" name="course_name" required>

            <label for="course_description">Course Description:</label>
            <textarea name="course_description" required></textarea>

            <div class="checkbox-container">
                <input type="checkbox" name="is_popular" id="is_popular">
                <label for="is_popular">Mark as Popular</label>
            </div>

            <button type="submit" name="add_course">Add Course</button>
        </form>
    </div>

    <!-- Display All Courses -->
    <table id="courseTable">
        <tr>
            <th>Course ID</th>
            <th>Course Name</th>
            <th>Description</th>
            <th>Popular</th>
            <th>Action</th>
        </tr>
        <?php while ($course = $courses->fetch_assoc()): ?>
            <tr id="row_<?= $course['course_id']; ?>">
                <td><?= $course['course_id']; ?></td>
                <td><?= $course['course_name']; ?></td>
                <td><?= $course['course_description']; ?></td>
                <td>
                    <input type="checkbox" class="toggle-popular" data-id="<?= $course['course_id']; ?>" <?= $course['is_popular'] ? 'checked' : '' ?>>
                </td>
                <td>
                    <button class="delete-btn" onclick="deleteCourse(<?= $course['course_id']; ?>)">Delete</button>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <!-- AJAX Script for Deleting & Toggling Popularity -->
    <script>
        function deleteCourse(courseId) {
            if (confirm("Are you sure you want to delete this course?")) {
                $.post("admin_courses.php", { delete_id: courseId }, function() {
                    $("#row_" + courseId).fadeOut();
                });
            }
        }

        $(".toggle-popular").change(function() {
            let courseId = $(this).data("id");
            let newStatus = $(this).is(":checked") ? 1 : 0;

            $.post("admin_courses.php", { toggle_id: courseId, new_status: newStatus });
        });
    </script>

</body>
</html>
