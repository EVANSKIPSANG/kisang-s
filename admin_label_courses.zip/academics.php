<?php
session_start();
include("db_connect.php"); // Include database connection

// Check if the user is logged in and their role
if (isset($_SESSION['role']) && $_SESSION['role'] === 'instructor') {
    $isInstructor = true;
} else {
    $isInstructor = false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academics</title>
    <link rel="stylesheet" href="academics.css">
</head>
<body>
    <div class="content">
        <h1>Welcome to the Academics Page</h1>
        <p>Explore available courses, resources, and academic information here.</p>

        <?php if ($isInstructor): ?>
            <a href="instructor_operations.php" class="button">Go to Instructor Operations</a>
        <?php endif; ?>

        <a href="student_resources.php" class="button">View Resources</a>
        <a href="user_homepage.php" class="back-button">Back to Homepage</a>
    </div>
</body>
</html>
