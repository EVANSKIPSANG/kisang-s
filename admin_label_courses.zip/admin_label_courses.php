<?php 
include 'db_conne88ct.php'; // Database connection

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_id = $_POST['course_id'];
    $is_popular = isset($_POST['is_popular']) ? 1 : 0; // Checkbox for Popular Course

    // Update course popularity status
    $sql = "UPDATE home_courses SET is_popular = ? WHERE course_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $is_popular, $course_id);

    if ($stmt->execute()) {
        echo "<script>alert('Course updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating course.');</script>";
    }
}

// Fetch all courses
$courses = $conn->query("SELECT course_id, course_name FROM home_courses");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Label Courses</title>
    <link rel="stylesheet" type="text/css" href="admin_label_courses.css">
</head>
<body>
    <div class="container">
        <h2>Label Courses</h2>
        <form method="POST">
            <label for="course">Select Course:</label>
            <select name="course_id" required>
                <?php while ($course = $courses->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($course['course_id']); ?>">
                        <?= htmlspecialchars($course['course_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label class="checkbox-label">
                <input type="checkbox" name="is_popular"> Mark as Popular
            </label>

            <button type="submit">Update Course</button>
        </form>
    </div>
</body>
</html>
