<?php
include('db_connect3.php');

$error_message = "";
$success_message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $unitCode = htmlspecialchars($_POST['unitCode']);
    $unitName = htmlspecialchars($_POST['unitName']);

    // Insert into the courses table using prepared statements
    $query = "INSERT INTO courses (unitCode, unitName) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $unitCode, $unitName);

    if ($stmt->execute()) {
        $success_message = "Course added successfully!";
    } else {
        $error_message = "Error adding course: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course</title>
    <link rel="stylesheet" type="text/css" href="add_course.css">
</head>
<body>
    <div class="container">
        <h2>Add a New Course</h2>

        <?php if ($error_message) echo "<p class='error'>$error_message</p>"; ?>
        <?php if ($success_message) echo "<p class='success'>$success_message</p>"; ?>

        <form method="post">
            <label for="unitCode">Unit Code:</label>
            <input type="text" name="unitCode" id="unitCode" required>

            <label for="unitName">Unit Name:</label>
            <input type="text" name="unitName" id="unitName" required>

            <button type="submit">Add Course</button>
        </form>
    </div>
</body>
</html>
