document.addEventListener("DOMContentLoaded", function () {
    const messageInput = document.getElementById("messageInput");
    const sendBtn = document.getElementById("sendBtn");
    const messagesContainer = document.getElementById("messages");
    const usernameInput = document.getElementById("usernameInput");
    const joinBtn = document.getElementById("joinBtn");
    let username = "";

    joinBtn.addEventListener("click", function () {
        username = usernameInput.value.trim();
        if (username) {
            document.getElementById("usernameContainer").style.display = "none";
            document.getElementById("chatBox").style.display = "flex";
        }
    });

    sendBtn.addEventListener("click", function () {
        sendMessage();
    });

    messageInput.addEventListener("keypress", function (event) {
        if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();
            sendMessage();
        }
    });

    function sendMessage() {
        const message = messageInput.value.trim();
        if (message && username) {
            fetch("chat7.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `username=${encodeURIComponent(username)}&message=${encodeURIComponent(message)}`
            }).then(() => {
                messageInput.value = "";
                loadMessages();
            });
        }
    }

    function loadMessages() {
        fetch("chat7.php")
            .then(response => response.json())
            .then(data => {
                messagesContainer.innerHTML = "";
                data.forEach(msg => {
                    const messageDiv = document.createElement("div");
                    messageDiv.classList.add("message");

                    if (msg.username === username) {
                        messageDiv.classList.add("me"); // Outgoing message
                    } else {
                        messageDiv.classList.add("other"); // Incoming message
                    }

                    messageDiv.textContent = `${msg.username}: ${msg.message}`;
                    messagesContainer.appendChild(messageDiv);
                });
            });
    }

    setInterval(loadMessages, 2000);
    loadMessages();
});
