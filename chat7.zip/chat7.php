<?php
$servername = "localhost";
$username = "root"; // Default XAMPP user
$password = ""; // Default XAMPP password (empty)
$database = "chat_db"; // Ensure this database exists

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle chat messages
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["message"])) {
    $username = $_POST["username"];
    $message = $_POST["message"];

    $sql = "INSERT INTO messages (username, message) VALUES ('$username', '$message')";
    $conn->query($sql);
}

// Handle delete request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_id"])) {
    $delete_id = $_POST["delete_id"];
    $conn->query("DELETE FROM messages WHERE id = $delete_id");
}

// Fetch all messages
$result = $conn->query("SELECT * FROM messages ORDER BY id DESC");
$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}
echo json_encode($messages);

$conn->close();
?>
