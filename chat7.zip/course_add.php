<?php
include('db_connect3.php');

$error_message = "";
$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_name = $_POST['course_name'];

    // Ensure the course name is not empty
    if (!empty($course_name)) {
        $query = "INSERT INTO courses (course_name) VALUES ('$course_name')";
        if (mysqli_query($conn, $query)) {
            $success_message = "Course added successfully!";
        } else {
            $error_message = "Error adding course: " . mysqli_error($conn);
        }
    } else {
        $error_message = "Course name cannot be empty.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Course</title>
</head>
<body>
    <h2>Add New Course</h2>

    <?php if ($error_message): ?><p style="color: red;"><?= $error_message; ?></p><?php endif; ?>
    <?php if ($success_message): ?><p style="color: green;"><?= $success_message; ?></p><?php endif; ?>

    <form action="course_add.php" method="POST">
        <label>Course Name:</label>
        <input type="text" name="course_name" required>
        <button type="submit">Add Course</button>
    </form>
</body>
</html>
