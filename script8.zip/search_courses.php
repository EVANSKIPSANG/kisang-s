<?php
include 'db_connect.php';

if (isset($_POST['search_query'])) {
    $search_query = mysqli_real_escape_string($conn, $_POST['search_query']);

    $query = "SELECT c.course_id, c.course_name, c.course_description, i.image_url 
              FROM home_courses c
              LEFT JOIN home_course_images i ON c.course_id = i.course_id
              WHERE c.course_name LIKE '%$search_query%' OR c.course_description LIKE '%$search_query%'";

    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div class='course-card'>
                    <img src='" . $row['image_url'] . "' alt='Course Image'>
                    <h3>" . $row['course_name'] . "</h3>
                    <p>" . $row['course_description'] . "</p>
                    <button>Enroll Now</button>
                  </div>";
        }
    } else {
        echo "<p>No courses found.</p>";
    }
}
?>
