// script.js
function toggleMenu() {
    const sidebar = document.getElementById("sidebar");
    sidebar.classList.toggle("active");
}

// Dropdown Toggle
const dropdownButtons = document.querySelectorAll(".dropdown-btn");
dropdownButtons.forEach((btn) => {
    btn.addEventListener("click", function () {
        const container = this.parentElement;
        container.classList.toggle("active");
    });
});
