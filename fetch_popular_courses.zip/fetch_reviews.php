<?php
include 'db_conne88ct.php';

$query = "SELECT r.student_name, c.course_name, r.review_text, r.rating, r.review_date 
          FROM home_reviews r
          JOIN home_courses c ON r.course_id = c.course_id
          ORDER BY r.review_date DESC LIMIT 5";

$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='review-card'>
                <h4>" . $row['student_name'] . " - " . $row['course_name'] . "</h4>
                <p>Rating: " . $row['rating'] . "/5</p>
                <p>\"" . $row['review_text'] . "\"</p>
                <small>Reviewed on: " . $row['review_date'] . "</small>
              </div>";
    }
} else {
    echo "<p>No reviews available.</p>";
}
?>
