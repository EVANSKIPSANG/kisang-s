<?php
include('db_connect2.php');

if (isset($_GET['student_id'])) {
    $student_id = $_GET['student_id'];

    // Fetch the courses the student is enrolled in
    $query = "SELECT courses.id, courses.course_name 
              FROM student_courses 
              JOIN courses ON student_courses.course_id = courses.id
              WHERE student_courses.student_id = '$student_id'";

    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) > 0) {
        echo "<h3>Enter Marks for Courses:</h3>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<label>{$row['course_name']}</label>";
            echo "<input type='number' name='marks[{$row['id']}]' min='0' max='100' required>";
        }
    } else {
        echo "<p style='color: red;'>This student is not enrolled in any courses.</p>";
    }
}
?>
