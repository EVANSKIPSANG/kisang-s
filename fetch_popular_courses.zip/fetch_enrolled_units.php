<?php
include('db_connect3.php');

if (isset($_POST['adm'])) {
    $adm = $_POST['adm'];
    
    // Fetch enrolled units for the selected student
    $query = "SELECT c.unitCode, c.unitName 
              FROM student_enrollments e 
              JOIN courses c ON e.unitCode = c.unitCode 
              WHERE e.adm = '$adm'";
    
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<label>{$row['unitName']}:</label>";
        echo "<input type='number' name='marks[{$row['unitCode']}]' min='0' max='100' required><br>";
    }
}
?>
