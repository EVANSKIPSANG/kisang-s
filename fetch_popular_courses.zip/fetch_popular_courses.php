<?php
include 'db_conne88ct.php'; // Database connection

$query = "SELECT c.course_id, c.course_name, c.course_description 
          FROM home_courses c
          WHERE c.is_popular = 1"; // Checking if the course is marked as popular

$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='course-card'>
                <img src='images/popular_courses.jpg' alt='Course Image'>
                <h3>" . $row['course_name'] . "</h3>
                <p>" . $row['course_description'] . "</p>
                <a href='main_index.php'><button>Explore Now</button></a>
              </div>";
    }
} else {
    echo "<p>No popular courses available.</p>";
}
?>
