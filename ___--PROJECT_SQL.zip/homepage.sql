-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2025 at 08:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homepage`
--

-- --------------------------------------------------------

--
-- Table structure for table `home_courses`
--

CREATE TABLE `home_courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `course_description` text NOT NULL,
  `is_popular` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `home_courses`
--

INSERT INTO `home_courses` (`course_id`, `course_name`, `course_description`, `is_popular`) VALUES
(1, 'Web Development', 'Learn HTML, CSS, and JavaScript.', 1),
(2, 'Data Science', 'Master Python and Machine Learning.', 1),
(3, 'Cyber Security', 'Ethical hacking and network security.', 1),
(4, 'complex analysis', 'complex numbers', 0);

-- --------------------------------------------------------

--
-- Table structure for table `home_course_images`
--

CREATE TABLE `home_course_images` (
  `image_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `home_course_images`
--

INSERT INTO `home_course_images` (`image_id`, `course_id`, `image_url`) VALUES
(1, 1, 'images/web_dev.jpg'),
(2, 2, 'images/data_science.jpg'),
(3, 3, 'images/cyber_security.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `home_images`
--

CREATE TABLE `home_images` (
  `image_id` int(11) NOT NULL,
  `image_type` enum('banner','promo') NOT NULL,
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `home_images`
--

INSERT INTO `home_images` (`image_id`, `image_type`, `image_url`) VALUES
(1, 'banner', 'images/banner1.jpg'),
(2, 'promo', 'images/promo1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `home_popular_courses`
--

CREATE TABLE `home_popular_courses` (
  `popular_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `home_popular_courses`
--

INSERT INTO `home_popular_courses` (`popular_id`, `course_id`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `home_reviews`
--

CREATE TABLE `home_reviews` (
  `review_id` int(11) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `course_id` int(11) NOT NULL,
  `review_text` text NOT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `review_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `home_reviews`
--

INSERT INTO `home_reviews` (`review_id`, `student_name`, `course_id`, `review_text`, `rating`, `review_date`) VALUES
(1, 'John Doe', 1, 'Excellent course!', 5, '2025-03-25 13:23:40'),
(2, 'Jane Smith', 2, 'Very informative and well structured.', 4, '2025-03-25 13:23:40'),
(4, ' EVANS KISANG', 3, 'excellent', 4, '2025-03-25 15:16:26'),
(5, 'euticus mwangi', 1, 'fantastic', 5, '2025-03-25 18:43:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `home_courses`
--
ALTER TABLE `home_courses`
  ADD PRIMARY KEY (`course_id`),
  ADD UNIQUE KEY `course_name` (`course_name`);

--
-- Indexes for table `home_course_images`
--
ALTER TABLE `home_course_images`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `home_images`
--
ALTER TABLE `home_images`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `home_popular_courses`
--
ALTER TABLE `home_popular_courses`
  ADD PRIMARY KEY (`popular_id`),
  ADD UNIQUE KEY `course_id` (`course_id`);

--
-- Indexes for table `home_reviews`
--
ALTER TABLE `home_reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `course_id` (`course_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `home_courses`
--
ALTER TABLE `home_courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `home_course_images`
--
ALTER TABLE `home_course_images`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `home_images`
--
ALTER TABLE `home_images`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `home_popular_courses`
--
ALTER TABLE `home_popular_courses`
  MODIFY `popular_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `home_reviews`
--
ALTER TABLE `home_reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `home_course_images`
--
ALTER TABLE `home_course_images`
  ADD CONSTRAINT `home_course_images_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `home_courses` (`course_id`) ON DELETE CASCADE;

--
-- Constraints for table `home_popular_courses`
--
ALTER TABLE `home_popular_courses`
  ADD CONSTRAINT `home_popular_courses_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `home_courses` (`course_id`) ON DELETE CASCADE;

--
-- Constraints for table `home_reviews`
--
ALTER TABLE `home_reviews`
  ADD CONSTRAINT `home_reviews_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `home_courses` (`course_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
