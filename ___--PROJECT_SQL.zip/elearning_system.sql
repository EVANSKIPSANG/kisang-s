-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2025 at 08:19 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elearning_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `unitCode` varchar(20) NOT NULL,
  `unitName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`unitCode`, `unitName`) VALUES
('303', 'ADVANCED TOPICS IN ENGINEERING'),
('345', 'SOFTWARE ENGINEERING'),
('999', 'MECHANICAL ENGINEERING');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `ADM` varchar(20) NOT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`ADM`, `firstName`, `lastName`) VALUES
('PA101/G/0009/21', 'evance', 'kyu'),
('PA101/G/4444/21', 'EVANS', 'KISANG'),
('PA101/G/5555/21', 'EUTICUS', ' MWANGI'),
('PA101/G/6666/21', 'NJUKUNA ', 'NJUKUSH'),
('PA101/G/9999/21', 'muhia', 'james');

-- --------------------------------------------------------

--
-- Table structure for table `student_enrollments`
--

CREATE TABLE `student_enrollments` (
  `id` int(11) NOT NULL,
  `ADM` varchar(20) DEFAULT NULL,
  `unitCode` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_enrollments`
--

INSERT INTO `student_enrollments` (`id`, `ADM`, `unitCode`) VALUES
(3, 'PA101/G/6666/21', '303'),
(4, 'PA101/G/9999/21', '999'),
(7, 'PA101/G/9999/21', '303'),
(8, 'PA101/G/9999/21', '999'),
(9, 'PA101/G/0009/21', '303'),
(10, 'PA101/G/0009/21', '999');

-- --------------------------------------------------------

--
-- Table structure for table `student_grades`
--

CREATE TABLE `student_grades` (
  `id` int(11) NOT NULL,
  `ADM` varchar(20) DEFAULT NULL,
  `unitCode` varchar(20) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL CHECK (`marks` between 0 and 100),
  `grade` char(1) DEFAULT NULL,
  `prescribed_resource` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_grades`
--

INSERT INTO `student_grades` (`id`, `ADM`, `unitCode`, `marks`, `grade`, `prescribed_resource`) VALUES
(7, 'PA101/G/6666/21', '303', 66, 'B', 'Intermediate Guides'),
(10, 'PA101/G/9999/21', '303', 88, 'A', 'Advanced Study Materials'),
(11, 'PA101/G/9999/21', '999', 36, 'E', 'Extra Coaching'),
(14, 'PA101/G/9999/21', '303', 22, 'E', 'Extra Coaching'),
(15, 'PA101/G/9999/21', '999', 56, 'C', 'Standard Books'),
(18, 'PA101/G/4444/21', '303', 88, 'A', 'Advanced Study Materials'),
(19, 'PA101/G/4444/21', '999', 88, 'A', 'Advanced Study Materials'),
(23, 'PA101/G/4444/21', '303', 88, 'A', 'Advanced Study Materials'),
(24, 'PA101/G/4444/21', '999', 88, 'A', 'Advanced Study Materials'),
(29, 'PA101/G/9999/21', '303', 22, 'E', 'Extra Coaching'),
(30, 'PA101/G/9999/21', '999', 44, 'D', 'Remedial Support'),
(31, 'PA101/G/0009/21', '303', 70, 'B', 'Intermediate Guides'),
(32, 'PA101/G/0009/21', '999', 88, 'A', 'Advanced Study Materials'),
(33, 'PA101/G/6666/21', '303', 66, 'B', 'Intermediate Guides'),
(34, 'PA101/G/6666/21', '999', 30, 'E', 'Extra Coaching'),
(35, 'PA101/G/5555/21', '303', 67, 'B', 'Intermediate Guides'),
(36, 'PA101/G/5555/21', '999', 88, 'A', 'Advanced Study Materials'),
(37, 'PA101/G/9999/21', '303', 33, 'E', 'Extra Coaching'),
(38, 'PA101/G/9999/21', '999', 98, 'A', 'Advanced Study Materials'),
(39, 'PA101/G/0009/21', '303', 88, 'A', 'Advanced Study Materials'),
(40, 'PA101/G/0009/21', '999', 22, 'E', 'Extra Coaching'),
(41, 'PA101/G/6666/21', '303', 66, 'B', 'Intermediate Guides'),
(42, 'PA101/G/6666/21', '999', 99, 'A', 'Advanced Study Materials'),
(43, 'PA101/G/0009/21', '303', 60, 'B', 'Intermediate Guides'),
(44, 'PA101/G/0009/21', '999', 54, 'C', 'Standard Books'),
(45, 'PA101/G/9999/21', '303', 87, 'A', 'Advanced Study Materials'),
(46, 'PA101/G/9999/21', '999', 61, 'B', 'Intermediate Guides'),
(47, 'PA101/G/0009/21', '303', 78, 'B', 'Intermediate Guides'),
(48, 'PA101/G/0009/21', '999', 77, 'B', 'Intermediate Guides'),
(49, 'PA101/G/4444/21', '303', 90, 'A', 'Advanced Study Materials'),
(50, 'PA101/G/4444/21', '345', 30, 'E', 'Extra Coaching'),
(51, 'PA101/G/4444/21', '999', 50, 'C', 'Standard Books'),
(52, 'PA101/G/4444/21', '303', 90, 'A', 'Advanced Study Materials'),
(53, 'PA101/G/4444/21', '345', 30, 'E', 'Extra Coaching'),
(54, 'PA101/G/4444/21', '999', 50, 'C', 'Standard Books');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`unitCode`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`ADM`);

--
-- Indexes for table `student_enrollments`
--
ALTER TABLE `student_enrollments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ADM` (`ADM`),
  ADD KEY `unitCode` (`unitCode`);

--
-- Indexes for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ADM` (`ADM`),
  ADD KEY `unitCode` (`unitCode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_enrollments`
--
ALTER TABLE `student_enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student_grades`
--
ALTER TABLE `student_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `student_enrollments`
--
ALTER TABLE `student_enrollments`
  ADD CONSTRAINT `student_enrollments_ibfk_1` FOREIGN KEY (`ADM`) REFERENCES `students` (`ADM`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_enrollments_ibfk_2` FOREIGN KEY (`unitCode`) REFERENCES `courses` (`unitCode`) ON DELETE CASCADE;

--
-- Constraints for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD CONSTRAINT `student_grades_ibfk_1` FOREIGN KEY (`ADM`) REFERENCES `students` (`ADM`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_grades_ibfk_2` FOREIGN KEY (`unitCode`) REFERENCES `courses` (`unitCode`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
