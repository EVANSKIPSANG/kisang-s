-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2025 at 08:24 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `username`, `message`, `created_at`) VALUES
(48, 'evans', 'morning', '2025-02-20 09:05:45'),
(49, 'kidungi', 'good morning to you', '2025-02-20 09:06:06'),
(50, 'evans', 'check this assignment', '2025-02-20 09:06:39'),
(51, 'kidungi', 'ChatGPT helps you get answers, find inspiration and be more productive. It is free to use and easy to try. Just ask and ChatGPT can help with writing, ..', '2025-02-20 09:07:24'),
(52, 'kidungi', '1', '2025-02-20 09:23:48'),
(53, 'evans', '2', '2025-02-20 09:23:55'),
(54, 'xyz', 'happy', '2025-02-20 09:25:12'),
(55, 'evans', 'moday', '2025-03-05 15:15:37'),
(56, 'evans', 'rererer', '2025-03-06 08:43:58'),
(57, 'evans', 'gfgdfgddfd', '2025-03-06 08:44:05'),
(58, 'kidungi', '6666666', '2025-03-06 08:44:50'),
(59, 'evans', 'ghfghjgfhjgfhjgfjgf', '2025-03-06 09:05:40'),
(60, 'samy', 'qrwerwetrwetwetwetwe', '2025-03-06 10:26:32'),
(61, 'japhet', 'MORNING MEMBERS', '2025-03-11 19:49:31'),
(62, 'japhet', 'jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj', '2025-03-11 20:14:15'),
(63, 'evans', 'hello japhet', '2025-03-11 20:15:11'),
(64, 'kidungi', 'eeregtrhyytynj', '2025-03-21 11:29:11'),
(65, 'jaophetr', 'xcvbn', '2025-03-21 11:30:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
