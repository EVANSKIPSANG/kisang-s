-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2025 at 08:23 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bio_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `instructors`
--

CREATE TABLE `instructors` (
  `instructor_id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `bio` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `x` varchar(255) DEFAULT NULL,
  `github` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `instructors`
--

INSERT INTO `instructors` (`instructor_id`, `name`, `occupation`, `bio`, `image`, `facebook`, `linkedin`, `x`, `github`) VALUES
('55555', 'evans kisang', 'Data scientist', 'evans kisang is a Data Scientist with expertise in machine learning, data analysis, and AI-driven solutions. With a strong background in statistics, programming (Python, R), and big data technologies, he specializes in extracting insights from complex datasets to drive business decisions.\r\n\r\nEvans has worked on projects involving predictive analytics, natural language processing (NLP), and data visualization, helping organizations leverage data for strategic growth. Passionate about AI innovation and automation, he continuously explores emerging trends in deep learning and cloud computing.', 'uploads/myself.jpg', 'kisang', 'kisang', 'https://x.com/home', 'kisang'),
('PA/2222/21', 'mwaura james', 'psychologist', 'Your CSS is already well-structured and clean! Below is a cleaned-up version that keeps everything intact while ensuring better readability and removing redundancies:\r\n\r\ncss\r\nCopy\r\nEdit\r\nYour CSS is already well-structured and clean! Below is a cleaned-up version that keeps everything intact while ensuring better readability and removing redundancies:\r\n\r\ncss\r\nCopy\r\nEdit\r\nYour CSS is already well-structured and clean! Below is a cleaned-up version that keeps everything intact while ensuring better readability and removing redundancies:\r\n\r\n', 'uploads/Screenshot6.png', 'sang', 'xxxx', 'kisang', 'sang');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `instructors`
--
ALTER TABLE `instructors`
  ADD PRIMARY KEY (`instructor_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
