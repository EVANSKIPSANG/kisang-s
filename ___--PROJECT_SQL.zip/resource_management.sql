-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2025 at 08:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resource_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `a`
--

CREATE TABLE `a` (
  `id` int(11) NOT NULL,
  `unitCode` varchar(50) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Upload` varchar(255) NOT NULL,
  `FileType` varchar(50) DEFAULT NULL,
  `FileSize` int(11) DEFAULT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a`
--

INSERT INTO `a` (`id`, `unitCode`, `Name`, `Upload`, `FileType`, `FileSize`, `Timestamp`) VALUES
(1, '500', 'BCOM', 'uploads/A/1738794058_Project Thesis Format.pdf', 'pdf', 162827, '2025-02-05 22:20:59');

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` int(11) NOT NULL,
  `unitCode` varchar(20) NOT NULL,
  `unitName` varchar(100) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `uploadTime` datetime NOT NULL,
  `sessionEnd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`id`, `unitCode`, `unitName`, `resource`, `uploadTime`, `sessionEnd`) VALUES
(1, '211', 'calculus assignment', '1738924550_Measure Theory and Integration )-5-31 - Copy.pdf', '2025-02-07 16:04:34', '2025-02-28 22:00:00'),
(2, '500', 'calculus assignment', 'project sketch.docx', '2025-03-04 06:35:27', '2025-03-04 16:30:00'),
(3, '444', 'stat', 'chapter 4..docx', '2025-03-30 20:38:30', '2025-03-31 21:38:00');

-- --------------------------------------------------------

--
-- Table structure for table `b`
--

CREATE TABLE `b` (
  `id` int(11) NOT NULL,
  `unitCode` varchar(50) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Upload` varchar(255) NOT NULL,
  `FileType` varchar(50) DEFAULT NULL,
  `FileSize` int(11) DEFAULT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `c`
--

CREATE TABLE `c` (
  `id` int(11) NOT NULL,
  `unitCode` varchar(50) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Upload` varchar(255) NOT NULL,
  `FileType` varchar(50) DEFAULT NULL,
  `FileSize` int(11) DEFAULT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `c`
--

INSERT INTO `c` (`id`, `unitCode`, `Name`, `Upload`, `FileType`, `FileSize`, `Timestamp`) VALUES
(1, '501', 'accounts and finance', 'uploads/C/1738796225_project sketch.docx', 'docx', 20752, '2025-02-05 22:57:05'),
(2, '444', 'ACCOUNTANCY', 'uploads/C/1738796467_main campus bronchures.pdf', 'pdf', 283519, '2025-02-05 23:01:07');

-- --------------------------------------------------------

--
-- Table structure for table `d`
--

CREATE TABLE `d` (
  `id` int(11) NOT NULL,
  `unitCode` varchar(50) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Upload` varchar(255) NOT NULL,
  `FileType` varchar(50) DEFAULT NULL,
  `FileSize` int(11) DEFAULT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `d`
--

INSERT INTO `d` (`id`, `unitCode`, `Name`, `Upload`, `FileType`, `FileSize`, `Timestamp`) VALUES
(1, '444', 'ACCOUNTANCY', 'uploads/D/1738796984_6794bd6c47985-2662project_f[1JANUARY] online learning platf.... (3) (1) (2).docx', 'docx', 1343825, '2025-02-05 23:09:44'),
(2, '888', 'aaaaaaaa', 'uploads/D/1738924550_Measure Theory and Integration )-5-31 - Copy.pdf', 'pdf', 729556, '2025-02-07 10:35:50'),
(3, '500', 'xyz', 'uploads/D/1741187387_PROJECT COMMUNITY.docx', 'docx', 56135, '2025-03-05 15:09:47');

-- --------------------------------------------------------

--
-- Table structure for table `e`
--

CREATE TABLE `e` (
  `id` int(11) NOT NULL,
  `unitCode` varchar(50) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Upload` varchar(255) NOT NULL,
  `FileType` varchar(50) DEFAULT NULL,
  `FileSize` int(11) DEFAULT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `solutions`
--

CREATE TABLE `solutions` (
  `id` int(11) NOT NULL,
  `admission` varchar(20) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `solution` varchar(255) NOT NULL,
  `submissionTime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `solutions`
--

INSERT INTO `solutions` (`id`, `admission`, `fname`, `lname`, `solution`, `submissionTime`) VALUES
(1, 'PA101/G/14444/21', 'evans ', 'kidang', '6794bd6c47985-2662project_f[1JANUARY] online learning platf.... (3) (1) (2).docx', '2025-02-07 15:07:49'),
(2, 'PA101/G/14444/21', 'evans ', 'kisang', 'project codes.docx', '2025-03-04 05:44:24'),
(3, 'PA101/G/14444/21', 'japhet', 'kyu', 'FINAL  PROJECT GUIDELINE  - updated (2).doc', '2025-03-11 19:48:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `a`
--
ALTER TABLE `a`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unitCode` (`unitCode`);

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `b`
--
ALTER TABLE `b`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unitCode` (`unitCode`);

--
-- Indexes for table `c`
--
ALTER TABLE `c`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unitCode` (`unitCode`);

--
-- Indexes for table `d`
--
ALTER TABLE `d`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unitCode` (`unitCode`);

--
-- Indexes for table `e`
--
ALTER TABLE `e`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unitCode` (`unitCode`);

--
-- Indexes for table `solutions`
--
ALTER TABLE `solutions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `a`
--
ALTER TABLE `a`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `b`
--
ALTER TABLE `b`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c`
--
ALTER TABLE `c`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `d`
--
ALTER TABLE `d`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `e`
--
ALTER TABLE `e`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `solutions`
--
ALTER TABLE `solutions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
