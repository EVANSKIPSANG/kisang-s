<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files
require __DIR__ . '/PHPMailer-master/src/Exception.php';
require __DIR__ . '/PHPMailer-master/src/PHPMailer.php';
require __DIR__ . '/PHPMailer-master/src/SMTP.php';
require __DIR__ . '/db_mail_connect.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lecturer_name = $_POST['lecturer_name'];
    $unit_name = $_POST['unit_name'];
    $unit_code = $_POST['unit_code'];
    $description = $_POST['description'];
    $class_time = $_POST['class_time'];

    // Fetch student emails from the 'students' table
    $query = "SELECT email FROM users";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die("❌ Error fetching student emails: " . mysqli_error($conn));
    }

    // Send emails to students
    while ($row = mysqli_fetch_assoc($result)) {
        $to = $row['email'];
        $subject = "Class Update: $unit_name ($unit_code)";
        $message = "
        Dear Student,\n\n
        This is to inform you about an update in your online class.\n
        🏫 **Unit Name:** $unit_name\n
        📚 **Unit Code:** $unit_code\n
        👨‍🏫 **Lecturer:** $lecturer_name\n
        🕒 **Time:** $class_time\n
        📝 **Description:** $description\n\n
        Please check your portal for more details.\n\n
        Regards,\n
        **Online Learning Administration**
        ";

        // Initialize PHPMailer
        $mail = new PHPMailer(true);

        try {
            // SMTP Configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'online1234platform@gmail.com'; // Replace with your Gmail
            $mail->Password = 'fqhz tkqw ksgd tzaw'; // Replace with your App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Email Content
            $mail->setFrom('online1234platform@gmail.com', 'Online Learning Admin');
            $mail->addAddress($to);
            $mail->Subject = $subject;
            $mail->Body = $message;
            $mail->isHTML(false);

            // Send email
            if ($mail->send()) {
                echo "✅ Email sent to: " . $to . "<br>";
            }
        } catch (Exception $e) {
            echo "❌ Email sending failed to $to: {$mail->ErrorInfo} <br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Online Class</title>
    <link rel="stylesheet" href="email_styles.css">
</head>
<body>
    <div class="container">
        <h2>Update Online Class</h2>
        <form action="lecturer_update_email.php" method="post">
            <label for="lecturer_name">Lecturer Name:</label>
            <input type="text" name="lecturer_name" required>

            <label for="unit_name">Unit Name:</label>
            <input type="text" name="unit_name" required>

            <label for="unit_code">Unit Code:</label>
            <input type="text" name="unit_code" required>

            <label for="description">Description:</label>
            <textarea name="description" required></textarea>

            <label for="class_time">Time:</label>
            <input type="datetime-local" name="class_time" required>

            <button type="submit">Notify Students</button>
        </form>
    </div>
</body>
</html>
