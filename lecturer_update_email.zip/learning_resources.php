<?php
include('db_connect3.php');

$error_message = "";
$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $grade = $_POST['grade'];
    $resource_name = $_POST['resource_name'];
    $resource_link = $_POST['resource_link'];

    if (empty($resource_name) || empty($resource_link)) {
        $error_message = "Both resource name and link are required.";
    } else {
        $query = "INSERT INTO learning_resources (grade, resource_name, resource_link) 
                  VALUES ('$grade', '$resource_name', '$resource_link')";
        if (mysqli_query($conn, $query)) {
            $success_message = "Learning resource added successfully!";
        } else {
            $error_message = "Error adding resource: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Learning Resource</title>
</head>
<body>
    <h2>Add Learning Resource for Grades</h2>

    <?php if ($error_message): ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <?php if ($success_message): ?>
        <p style="color: green;"><?php echo $success_message; ?></p>
    <?php endif; ?>

    <form action="learning_resources.php" method="POST">
        <label for="grade">Grade:</label>
        <select name="grade" id="grade" required>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
            <option value="E">E</option>
        </select><br>

        <label for="resource_name">Resource Name:</label>
        <input type="text" name="resource_name" id="resource_name" required><br>

        <label for="resource_link">Resource Link:</label>
        <input type="text" name="resource_link" id="resource_link" required><br>

        <button type="submit">Add Resource</button>
    </form>
</body>
</html>
