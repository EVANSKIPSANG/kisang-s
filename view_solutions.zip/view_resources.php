<?php
session_start();
include('db_connect2.php');

// Assuming the student is logged in and their ID is stored in session
$student_id = $_SESSION['user_id'];

// Fetch student's grade
$query = "SELECT grade FROM student_grades WHERE student_id = '$student_id' ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $query);
$grade = mysqli_fetch_assoc($result)['grade'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Resources</title>
</head>
<body>
    <h2>View Resources</h2>

    <?php if ($grade): ?>
        <p>Your Grade: <?= $grade ?></p>
    <?php else: ?>
        <p>Your grade is not available yet.</p>
    <?php endif; ?>

</body>
</html>
