<?php
// Include database connection
include('db_connect_library.php');

// Check if category (A, B, C, D, or E) is set in the URL
$category = isset($_GET['category']) ? $_GET['category'] : 'A'; // Default to category A

// Define valid categories
$valid_categories = ['A', 'B', 'C', 'D', 'E'];

// Check if category is valid
if (!in_array($category, $valid_categories)) {
    die('Invalid category.');
}

// Fetch resources based on the selected category
$query = "SELECT * FROM $category";
$result = mysqli_query($conn, $query);

if (!$result) {
    die('Error fetching resources: ' . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Resources - Category <?php echo htmlspecialchars($category); ?></title>
    <link rel="stylesheet" href="view_resources_lib.css"> <!-- Link to the new CSS file -->

</a>
</head>
<body>

    <h1>Resources for Category <?php echo htmlspecialchars($category); ?></h1>

    <!-- Buttons to switch between categories -->
    <div class="button-container">
        <button onclick="window.location.href='view_resources_lib.php?category=A'">Category A</button>
        <button onclick="window.location.href='view_resources_lib.php?category=B'">Category B</button>
        <button onclick="window.location.href='view_resources_lib.php?category=C'">Category C</button>
        <button onclick="window.location.href='view_resources_lib.php?category=D'">Category D</button>
        <button onclick="window.location.href='view_resources_lib.php?category=E'">Category E</button>
    </div>

    <table>
        <thead>
            <tr>
                <th>Unit Code</th>
                <th>Resource Name</th>
                <th>Download</th>
                <th>Upload Timestamp</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Check if any resources are found
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['unitCode']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Name']) . "</td>";
                    echo "<td><a href='" . htmlspecialchars($row['Upload']) . "' download>Download</a></td>";
                    echo "<td>" . htmlspecialchars($row['Timestamp']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No resources available.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <a href="user_homepage.php" class="back-home">Back to Home</a> <!-- Styled home button -->

</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>