<?php
include 'db_connect_assignment.php';

$query = "SELECT * FROM solutions ORDER BY admission ASC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Solutions</title>
    <link rel="stylesheet" href="view_solutions.css">
</head>
<body>
    <h2>Student Solutions To Assignment:</h2>
    <table>
        <tr>
            <th>Admission</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Solution</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?php echo $row['admission']; ?></td>
                <td><?php echo $row['fname']; ?></td>
                <td><?php echo $row['lname']; ?></td>
                <td><a href="solutions/<?php echo $row['solution']; ?>" download>Download</a></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
