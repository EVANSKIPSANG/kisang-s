<?php
// view_submissions8.php - Page to display submissions for a group
include 'db_connect8.php';

$group_id = $_GET['group_id']; // Get the group ID from the URL

// Fetch all submissions for the selected group
$submissionsQuery = "SELECT * FROM submissions8 WHERE group_id = '$group_id'";
$submissionsResult = $conn->query($submissionsQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Submissions</title>
</head>
<body>
    <h1>Group Submissions</h1>

    <h2>Submissions for Group <?= $group_id ?></h2>
    
    <?php while ($submission = $submissionsResult->fetch_assoc()) { ?>
        <div class="submission">
            <h3>Admission Number: <?= $submission['admission_number']; ?></h3>
            <p>Submitted on: <?= $submission['submission_time']; ?></p>
            <p>Work: <?= nl2br($submission['work_content']); ?></p>
        </div>
    <?php } ?>
</body>
</html>
