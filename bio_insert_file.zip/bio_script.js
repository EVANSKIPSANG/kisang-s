document.addEventListener("DOMContentLoaded", function () {
    const cards = document.querySelectorAll(".bio-card");

    cards.forEach(card => {
        const bioText = card.querySelector(".bio-text");

        // Show bio on hover (temporary view)
        card.addEventListener("mouseenter", function () {
            if (!card.classList.contains("active")) {
                bioText.style.display = "block";
            }
        });

        // Hide bio when mouse leaves (if not clicked)
        card.addEventListener("mouseleave", function () {
            if (!card.classList.contains("active")) {
                bioText.style.display = "none";
            }
        });

        // When card is clicked, make it static (stay open)
        card.addEventListener("click", function (event) {
            event.stopPropagation(); // Prevent clicking from closing immediately

            // Close all other bios first
            cards.forEach(otherCard => {
                if (otherCard !== card) {
                    otherCard.classList.remove("active");
                    otherCard.querySelector(".bio-text").style.display = "none";
                }
            });

            // Toggle active state on the clicked card
            card.classList.toggle("active");
            bioText.style.display = card.classList.contains("active") ? "block" : "none";
        });
    });

    // Close all bios when clicking outside
    document.addEventListener("click", function () {
        cards.forEach(card => {
            card.classList.remove("active");
            card.querySelector(".bio-text").style.display = "none";
        });
    });
});
