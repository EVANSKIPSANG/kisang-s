<?php
include 'bio_db.php'; // Include database connection

$sql = "SELECT * FROM instructors";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructors' Bios</title>
    <link rel="stylesheet" href="bio_view.css">
    
    <!-- 🌟 Added Background Image Style -->
    <style>
        body {
            background: url('images/bio2.jpg') no-repeat center center fixed;
            background-size: cover;
        }
    </style>
</head>
<body>

    <!-- 🌟 Navigation Bar (Added) -->
    <div class="navbar">
        <a href="" class="nav-link">🌟WELCOME TO ONLINE LEARNING PLATFORM🌟</a>
       <!-- <a href="courses.php" class="nav-link">Courses1</a> -->
       <!-- <a href="students.php" class="nav-link">Students</a> -->
        <a href="main_index.php" class="nav-link">Login(student)</a>
        <a href="instructor_login.html" class="nav-link">Admin</a>
    </div>

    <!-- <h2>Instructors' Bios</h2> -->
    <div class="bio-container">
        <?php while ($row = $result->fetch_assoc()) { ?>
            <div class="bio-card">
                <?php if (!empty($row['image'])) { ?>
                    <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="Instructor Image" class="bio-image">
                <?php } ?>
                
                <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                <p><strong>Occupation:</strong> <?php echo htmlspecialchars($row['occupation']); ?></p>

                <div class="social-links">
                    <?php if (!empty($row['facebook'])) { ?>
                        <a href="<?php echo htmlspecialchars($row['facebook']); ?>" target="_blank">
                            <img src="images/facebook.png" alt="Facebook"> 
                        </a>
                    <?php } ?>

                    <?php if (!empty($row['linkedin'])) { ?>
                        <a href="<?php echo htmlspecialchars($row['linkedin']); ?>" target="_blank">
                            <img src="images/linkedin.png" alt="LinkedIn"> 
                        </a>
                    <?php } ?>

                    <?php if (!empty($row['x'])) { ?>
                        <a href="<?php echo htmlspecialchars($row['x']); ?>" target="_blank">
                            <img src="images/x.png" alt="X (Twitter)"> 
                        </a>
                    <?php } ?>

                    <?php if (!empty($row['github'])) { ?>
                        <a href="<?php echo htmlspecialchars($row['github']); ?>" target="_blank">
                            <img src="images/github.png" alt="GitHub"> 
                        </a>
                    <?php } ?>
                </div>

                <!-- Bio Content (Initially Hidden) -->
                <div class="bio-text">
                    <p><strong>Bio:</strong> <?php echo nl2br(htmlspecialchars($row['bio'])); ?></p>
                </div>
            </div>
        <?php } ?>
    </div>

    <!-- Link to JavaScript File -->
    <script src="bio_script.js"></script>

</body>
</html>
