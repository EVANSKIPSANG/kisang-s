<?php
include 'bio_db.php'; // Include database connection

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<p style='color:red; text-align:center;'>Please enter an ID first! <a href='bio_search.php'>Go back</a></p>";
    exit();
}

$id = $conn->real_escape_string($_GET['id']); // Prevent SQL Injection

// Fetch instructor details
$query = "SELECT * FROM instructors WHERE instructor_id = '$id'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "<p style='color:red; text-align:center;'>Instructor not found! <a href='bio_search.php'>Try again</a></p>";
    exit();
}

// Handle update submission
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $occupation = $conn->real_escape_string($_POST['occupation']);
    $bio = $conn->real_escape_string($_POST['bio']);
    $facebook = $conn->real_escape_string($_POST['facebook']);
    $linkedin = $conn->real_escape_string($_POST['linkedin']);
    $x = $conn->real_escape_string($_POST['x']);
    $github = $conn->real_escape_string($_POST['github']);

    // Handle profile image upload (optional)
    if (!empty($_FILES["image"]["name"])) {
        $image = "uploads/" . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $image);
    } else {
        $image = $row['image']; // Keep the old image if not updated
    }

    // Update the instructor's information
    $update_query = "UPDATE instructors SET 
                     name='$name', occupation='$occupation', bio='$bio', 
                     image='$image', facebook='$facebook', linkedin='$linkedin', 
                     x='$x', github='$github'
                     WHERE instructor_id='$id'";

    if ($conn->query($update_query)) {
        echo "<p style='color:green; text-align:center;'>Update successful! <a href='bio_edit.php?id=$id'>Refresh</a></p>";
    } else {
        echo "<p style='color:red; text-align:center;'>Error updating record: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="bio_edit.css">
</head>
<body>
    <h2>My Bio</h2>
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['instructor_id']); ?>">

        <label>Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required><br>

        <label>Occupation:</label>
        <input type="text" name="occupation" value="<?php echo htmlspecialchars($row['occupation']); ?>" required><br>

        <label>Bio:</label>
        <textarea name="bio" required><?php echo htmlspecialchars($row['bio']); ?></textarea><br>

        <label>Profile Image:</label>
        <input type="file" name="image"><br>
        <?php if (!empty($row['image'])): ?>
            <img src="<?php echo htmlspecialchars($row['image']); ?>" width="100"><br>
        <?php endif; ?>

        <label>Facebook:</label>
        <input type="text" name="facebook" value="<?php echo htmlspecialchars($row['facebook']); ?>"><br>

        <label>LinkedIn:</label>
        <input type="text" name="linkedin" value="<?php echo htmlspecialchars($row['linkedin']); ?>"><br>

        <label>X (Twitter):</label>
        <input type="text" name="x" value="<?php echo htmlspecialchars($row['x']); ?>"><br>

        <label>GitHub:</label>
        <input type="text" name="github" value="<?php echo htmlspecialchars($row['github']); ?>"><br>

        <button type="submit" name="update">Update Bio</button>
    </form>
</body>
</html>
