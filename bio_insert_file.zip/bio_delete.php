<?php
include 'bio_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = trim($_POST['id']);

    // Check if the instructor ID exists
    $check_sql = "SELECT * FROM instructors WHERE instructor_id='$id'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        // If exists, delete the record
        $delete_sql = "DELETE FROM instructors WHERE instructor_id='$id'";
        if ($conn->query($delete_sql) === TRUE) {
            $message = "Your bio was successfully dropped.";
        } else {
            $message = "Error deleting record: " . $conn->error;
        }
    } else {
        $message = "You entered the wrong instructor ID. Please retry.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Instructor Bio</title>
    <link rel="stylesheet" href="bio_delete.css">
</head>
<body>

    <div class="container">
        <h2>Delete your Bio</h2>

        <?php if (isset($message)) { ?>
            <p class="message"><?php echo $message; ?></p>
        <?php } ?>

        <form method="post">
            <label>Instructor ID:</label>
            <input type="text" name="id" required><br>
            <button type="submit" name="delete">Delete Bio</button>
        </form>
    </div>

</body>
</html>
