<?php
include 'bio_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $instructor_id = $_POST['instructor_id'];
    $name = $_POST['name'];
    $occupation = $_POST['occupation'];
    $bio = $_POST['bio'] ?: NULL;
    $facebook = $_POST['facebook'] ?: NULL;
    $linkedin = $_POST['linkedin'] ?: NULL;
    $x = $_POST['x'] ?: NULL;
    $github = $_POST['github'] ?: NULL;

    // Handle image upload
    $image = NULL;
    if (!empty($_FILES["image"]["name"])) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
        $image = $target_file;
    }

    $sql = "INSERT INTO instructors (instructor_id, name, occupation, bio, image, facebook, linkedin, x, github) 
            VALUES ('$instructor_id', '$name', '$occupation', '$bio', '$image', '$facebook', '$linkedin', '$x', '$github')";

    if ($conn->query($sql) === TRUE) {
        echo "Bio inserted successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="bio_insert.css">
</head>
<body>

    <!-- Delete Button -->
    <a href="bio_search.php" class="delete-btn">Edit</a> 
    <a href="bio_delete.php" class="drop-bio-btn">drop _bio</a>
   <!-- <a href="bio_edit.php" class="drop-bio-btn">edit</a> -->

    <h2>Customize your Bio</h2>
    <form method="post" enctype="multipart/form-data">
        <label>ID:</label>
        <input type="text" name="instructor_id" required><br>
        
        <label>Name:</label>
        <input type="text" name="name" required><br>
        
        <label>Occupation:</label>
        <input type="text" name="occupation" required><br>

        <label>Bio Description:</label>
        <textarea name="bio" rows="4"></textarea><br>

        <label>Profile Image:</label>
        <input type="file" name="image"><br>
        
        <label>Facebook:</label>
        <input type="text" name="facebook"><br>
        
        <label>LinkedIn:</label>
        <input type="text" name="linkedin"><br>
        
        <label>X (Twitter):</label>
        <input type="text" name="x"><br>
        
        <label>GitHub:</label>
        <input type="text" name="github"><br>
        
        <button type="submit">Insert Bio</button>
    </form>

</body>
</html>
