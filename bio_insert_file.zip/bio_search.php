<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Find Instructor Bio</title>
    <link rel="stylesheet" href="bio_search.css">
</head>
<body>
    <div class="container">
        <h2>Find Instructor Bio</h2>
        <form action="bio_edit.php" method="GET">
            <label for="id">Enter Instructor ID:</label>
            <input type="text" name="id" id="id" required>
            <button type="submit">Proceed to Edit</button>
        </form>
    </div>
</body>
</html>
