<?php
include('db_connect3.php');

function calculateGrade($marks) {
    return ($marks >= 80) ? 'A' : (($marks >= 60) ? 'B' : (($marks >= 50) ? 'C' : (($marks >= 40) ? 'D' : 'E')));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ADM = $_POST['ADM'];
    foreach ($_POST['marks'] as $unitCode => $marks) {
        $grade = calculateGrade($marks);
        $resource = ($grade == 'A') ? "Advanced Study Materials" :
                    (($grade == 'B') ? "Intermediate Guides" :
                    (($grade == 'C') ? "Standard Books" :
                    (($grade == 'D') ? "Remedial Support" : "Extra Coaching")));

        $query = "INSERT INTO student_grades (ADM, unitCode, marks, grade, prescribed_resource)
                  VALUES ('$ADM', '$unitCode', '$marks', '$grade', '$resource')";
        mysqli_query($conn, $query);
    }
    echo "Marks entered successfully!";
}

// Fetch students
$student_result = mysqli_query($conn, "SELECT * FROM students");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Enter Marks</title>
</head>
<body>
    <form method="post">
        <label>Select Student:</label>
        <select name="ADM">
            <?php while ($row = mysqli_fetch_assoc($student_result)): ?>
                <option value="<?= $row['ADM'] ?>"><?= $row['firstName'] . " " . $row['lastName'] ?></option>
            <?php endwhile; ?>
        </select>

        <h3>Enter Marks:</h3>
        <?php $course_result = mysqli_query($conn, "SELECT * FROM courses"); ?>
        <?php while ($row = mysqli_fetch_assoc($course_result)): ?>
            <label><?= $row['unitName'] ?>:</label>
            <input type="number" name="marks[<?= $row['unitCode'] ?>]" min="0" max="100"><br>
        <?php endwhile; ?>

        <button type="submit">Submit Marks</button>
    </form>
</body>
</html>
